const API_KEY = "9d33e1d9ecea52e222a04b84b0cc9c95"; // Reemplaza con tu API Key de Last.fm
const NUM_RECOMMENDATIONS = 5; // Número de canciones a mostrar por búsqueda
let currentTracks = []; // Guardar canciones actuales para recomendaciones

document.getElementById("searchBtn").addEventListener("click", fetchTracks);
document.getElementById("newRecsBtn").addEventListener("click", recommendMoreTracks);

function fetchTracks() {
  const query = document.getElementById("searchInput").value.trim();
  if (!query) {
    alert("Por favor, ingresa un artista o género.");
    return;
  }

  const url = `https://ws.audioscrobbler.com/2.0/?method=tag.gettoptracks&tag=${query}&api_key=${API_KEY}&format=json`;

  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      const results = document.getElementById("results");
      results.innerHTML = ""; // Limpiar resultados anteriores
      currentTracks = []; // Reiniciar las canciones guardadas

      if (!data.tracks || !data.tracks.track.length) {
        results.innerHTML = "<p>No se encontraron resultados.</p>";
        return;
      }

      currentTracks = data.tracks.track; // Guardar todas las canciones disponibles

      document.getElementById("newRecsBtn").style.display = "inline-block"; // Mostrar el botón de nuevas recomendaciones
      recommendMoreTracks(); // Mostrar las primeras recomendaciones
    })
    .catch((error) => {
      console.error("Error al obtener los datos:", error);
      alert("Ocurrió un error al obtener las recomendaciones.");
    });
}

function recommendMoreTracks() {
  const results = document.getElementById("results");
  results.innerHTML = ""; // Limpiar resultados anteriores

  if (currentTracks.length === 0) {
    results.innerHTML = "<p>No hay más recomendaciones disponibles.</p>";
    return;
  }

  // Obtener las primeras N canciones
  const tracksToShow = currentTracks.slice(0, NUM_RECOMMENDATIONS);

  tracksToShow.forEach((track) => {
    // Generar un enlace de búsqueda para YouTube
    const youtubeSearchLink = `https://www.youtube.com/results?search_query=${encodeURIComponent(
      `${track.name} ${track.artist.name}`
    )}`;

    const trackElement = document.createElement("div");
    trackElement.className = "track";
    trackElement.innerHTML = `
      <h3>${track.name}</h3>
      <p>Artista: ${track.artist.name}</p>
      <p><a href="${track.url}" target="_blank">Escuchar en Last.fm</a></p>
      <p><a href="${youtubeSearchLink}" target="_blank">Buscar en YouTube</a></p>
    `;
    results.appendChild(trackElement);
  });

  // Eliminar las canciones mostradas de la lista
  currentTracks = currentTracks.slice(NUM_RECOMMENDATIONS);
}
